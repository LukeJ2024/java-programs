package Labs;

public class helloWorld {
    public static void main(String[]args){
        //Prints hello world
    System.out.println("Hello World!");
    }
}
