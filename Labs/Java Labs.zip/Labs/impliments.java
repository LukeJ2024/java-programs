package Labs;

public class impliments {

}
