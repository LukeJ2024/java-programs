package Labs;

import javax.swing.JFrame;

public class Lab05 {
    public static void main(String[]args){
        MyFrame window = new MyFrame("Tempature Converter");
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        window.setSize(300,300);
        window.setVisible(true);
    }
}
