package Labs;

public class Lab10 {
    public static void main(String[] args) {
        String s = "((((((((()))))))))";
        System.out.println(Matching.nestParen(s));
    }
}