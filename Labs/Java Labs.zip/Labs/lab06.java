package Labs;

import javax.swing.JFrame;

public class lab06 {
    public static void main(String[] args) {
        frame window = new frame();
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        window.setSize(500,500);
        window.setVisible(true);
    }
}
